README

CARD USER I.D. LIST 2.xlsx is our db for now. 

these files should be in the same directory as SummaryReport.exe:
-CARD USER I.D. LIST 2.xlsx
-summaryreporticon.ico

system will not run unless these files are available


steps:
1) click open file button to load daily complete.xls file
2) select checkbox to pick which file to generate
3) cilck generate report button to generate reports and save to file
4) prompts will appear for filename of files to be saved
5) wait for notes to show the file locations of the new files.
6) if stuck in "generating..." ensure that files are not opened  in another application